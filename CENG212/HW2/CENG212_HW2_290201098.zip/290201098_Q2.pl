?-is_prerequisite(X, Y).
?-is_four_credit(X).
?-is_three_credit(X).
?-teaches(X, Y).
?-course_core(X).