# Deniz Kaya 280201033
# Kürşat Çağrı Yakıcı 290201098

number = input("Please enter the year which is to be converted into roman numeral: ")
numberInt = int(number)


if numberInt <= 0: # eliminating the invalid values
    print("Zero and negative integers cannot be represented with roman numerals")

elif numberInt >= 4000: # eliminating the invalid values
    print("Integers greater than 3999 cannot be represented with roman numerals")

elif numberInt < 4000:
    
    # saving each digit of the number individually
    thousands = int(numberInt / 1000) * 1000
    hundreds = int((numberInt - thousands) / 100) * 100
    tens = int((numberInt - thousands - hundreds) / 10) * 10
    ones = int(numberInt - thousands - hundreds - tens)

    # saving the letters for the thousands
    if thousands >= 0 and thousands <=3000:
        thousandLetter = "M" * int((thousands/1000))
    
    # saving the letters for the hundreds
    if hundreds >= 0 and hundreds <= 300:
        hundredLetter = "C" * int(hundreds/100)
    elif hundreds == 400:
        hundredLetter = "CD"
    elif hundreds >= 500 and hundreds <= 800:
        hundredLetter = "D" + "C" * int(hundreds/100 - 5)
    elif hundreds == 900:
        hundredLetter = "CM"

    # saving the letters for the tens
    if tens >= 0 and tens <= 30:
        tenLetter = "X" * int(tens/10)
    elif tens == 40:
        tenLetter = "XL"
    elif tens >= 50 and tens <= 80:
        tenLetter = "L" + "X" * int(tens/10 - 5)
    elif tens == 90:
        tenLetter = "XC"

    # saving the letters for the ones
    if ones >= 0 and ones <= 3:
        oneLetter = "I" * ones
    elif ones == 4:
        oneLetter = "IV"
    elif ones >= 5 and ones <= 8:
        oneLetter = "V" + "I" * int(ones - 5)
    elif ones == 9:
        oneLetter = "IX"

    # concatenating the letters for each power of ten
    romanNumeral = thousandLetter + hundredLetter + tenLetter + oneLetter

    print("The number you have entered is written in roman numeral as follows: " + romanNumeral)

else:
    print("Please enter a valid number")
