# Deniz Kaya 280201033
# Kürşat Çağrı Yakıcı 290201098

month = input("Please enter the name of the month in lower case: ")

if month == "january" or month == "february" or month == "december":
    print(month + " is in Winter")
elif month == "march" or month == "april" or month == "may":
    print(month + " is in Spring")
elif month == "june" or month == "july" or month == "august":
    print(month + " is in Sommer")
elif month == "september" or month == "october" or month == "november":
    print(month + " is in Autumn")
else:
    print("Please enter a valid input")